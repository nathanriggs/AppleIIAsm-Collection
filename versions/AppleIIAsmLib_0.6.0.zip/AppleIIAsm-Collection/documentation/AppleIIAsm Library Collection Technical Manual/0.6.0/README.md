# README

This is the current documentation for the entire collection, v0.6.0. Note that the documentation is incomplete because I am working my way through the changes and documentation disk-by-disk.

To access the documentation in its current state thus far, start with [The Title and Table of Contents](0.0%20Title%20to%20TOC.md)
